#include <iostream>
#include "Producto.h"
#include "Inventario.h"
#include "Carrito.h"
#include "Tienda.h"

using std::cout;
using std::cin;
using std::endl;

int main()
{
    Tienda iniciar;
    iniciar.inicio_tienda();



    
  
    return 0;
  }